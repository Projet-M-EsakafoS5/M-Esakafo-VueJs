<template>  
  <div>  
    <h1>Connexion</h1>  
    <input type="email" v-model="email" placeholder="Email" />  
    <input type="password" v-model="password" placeholder="Mot de passe" />  
    <button @click="handleSignIn">Se connecter</button>  
    <p v-if="errorMessage">{{ errorMessage }}</p>  
  </div>  
</template>  

<script>  
import { ref } from 'vue';  
import { useRouter } from 'vue-router';   
import { auth } from '../firebase'; // Assurez-vous que ce chemin soit correct  
import { signInWithEmailAndPassword } from "firebase/auth"; // Importation de la méthode d'authentification  

export default {  
  setup() {  
    const email = ref("admin@gmail.com");  // Adresse email  
    const password = ref("123456");  // Mot de passe  
    const errorMessage = ref("");  // Message d'erreur  
    const router = useRouter();   // Instance du router  

    const handleSignIn = async () => {  
      try {  
        // Authentification avec Firebase  
        const userCredential = await signInWithEmailAndPassword(auth, email.value, password.value);  
        console.log("Utilisateur connecté :", userCredential);  

        // Vérifiez l'UID de l'utilisateur  
        if (userCredential.user.uid === 'ejQ0HUOcOQdrETBy6k3ZmhI0tOu1') {  
          console.log("Redirection vers /ingredient");  
          router.push('/ingredient');  // Redirige vers le composant Ingredient  
        } else {  
          console.log("Redirection vers / pour les utilisateurs non admin");  
          router.push('/');  // Redirige vers la page d'accueil  
        }  

      } catch (error) {  
        errorMessage.value = error.message;  // Affichage du message d'erreur  
        console.error("Erreur lors de la connexion :", error);  
      }  
    };  

    return {  
      email,  
      password,  
      handleSignIn,  
      errorMessage   
    };  
  },  
};  
</script>